from distutils.core import setup

setup(
    name = 'python_udemy',
    version = '1.0.0',
    packages = ['lesson_package','lesson_package.talk','lesson_package.tools'],
    url = '',
    license = 'Free',
    author = 'daiki',
    author_email = '',
    description = 'Sample package'
)